"""Balanced E1 repartitioning using an unmodified audited analysis engine."""
import os
for name in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']:
    os.environ[name]='1'
import sys
sys.dont_write_bytecode=True
from pathlib import Path
P=Path(__file__).resolve().parent
sys.path.insert(0,str(P/'vendor'))
import argparse
from concurrent.futures import ProcessPoolExecutor,as_completed
from datetime import datetime,timezone
import hashlib
import importlib.metadata
import json
import time
import numpy as np
import pandas as pd
import e1_reanalysis as engine

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p): return json.loads(Path(p).read_text(encoding='utf-8'))
def write(p,v):
    Path(p).parent.mkdir(parents=True,exist_ok=True)
    Path(p).write_text(json.dumps(v,ensure_ascii=False,allow_nan=False,separators=(',',':'))+'\n',encoding='utf-8')
def now(): return datetime.now(timezone.utc).isoformat()
def config(): return read(P/'protocol.json')

def make_splits():
    cfg=config(); result={}
    for instance in cfg['instances']:
        result[instance]={'S000':{k:v.tolist() for k,v in engine.split_replicates(instance).items()}}
        for block in range(cfg['shuffle_blocks']):
            ordered=sorted(range(40),key=lambda r:hashlib.sha256(
                f'e1-balanced-{cfg["seed"]}|{instance}|{block}|{r}'.encode()).hexdigest())
            groups=[ordered[k*10:(k+1)*10] for k in range(4)]
            for k in range(4):
                key=f'S{1+4*block+k:03d}'
                result[instance][key]=dict(fit=groups[k],select=groups[(k+1)%4],
                    test=groups[(k+2)%4]+groups[(k+3)%4])
    return result

def check_splits(splits):
    assert set(splits)==set(config()['instances'])
    for instance,items in splits.items():
        assert set(items)=={f'S{s:03d}' for s in range(21)}
        tally={k:np.zeros(40,dtype=int) for k in ['fit','select','test']}
        for split,groups in items.items():
            assert [len(groups[k]) for k in tally]==[10,10,20]
            allids=sum([groups[k] for k in tally],[])
            assert sorted(allids)==list(range(40))
            if split!='S000':
                for k in tally: tally[k][groups[k]]+=1
        for k,n in [('fit',5),('select',5),('test',10)]: assert np.all(tally[k]==n)
        canonical=[tuple(sorted(x['fit']))+tuple(sorted(x['select'])) for s,x in items.items()]
        assert len(set(canonical))==21

def freeze():
    if (P/'freeze.json').exists(): raise FileExistsError('Already frozen')
    splits=make_splits();check_splits(splits);write(P/'splits.json',splits)
    root=P.parents[1]
    protected=[root/'outputs/revision_v41/manuscript/main.tex',
        root/'outputs/revision_v41/decision_residual_fields_theory_v41.pdf',
        root/'outputs/revision_v41_manuscrito.zip',
        root/'outputs/reproduccion_plan_v4/paquete_reproduccion_v4.zip']
    sources=[p for p in sorted(P.rglob('*')) if p.is_file() and
        (p.suffix=='.py' or p.name in ['protocol.json','PROTOCOLO.txt','splits.json'])]
    versions={k:importlib.metadata.version(k) for k in ['numpy','scipy','pandas','scikit-learn','cvxpy','clarabel','scs','matplotlib']}
    frozen=dict(timestamp_utc=now(),source_sha256={p.relative_to(P).as_posix():sha(p) for p in sources},
        inputs_sha256={p.relative_to(P).as_posix():sha(p) for p in sorted((P/'inputs').glob('C*.npz'))},
        baseline_sha256={p.relative_to(P).as_posix():sha(p) for p in sorted((P/'baseline').iterdir())},
        protected_sha256={str(p):sha(p) for p in protected},versions=versions,python=sys.version,
        design_scope='Local freeze before alternative results, not before the historical E1 outcomes; retrospective sensitivity analysis.')
    write(P/'freeze.json',frozen)
    (P/'requirements.txt').write_text('\n'.join(f'{k}=={v}' for k,v in versions.items())+'\n',encoding='utf-8')
    print('FROZEN: 20 balanced alternative splits, 48 instances, two budgets; all source/input hashes.',flush=True)

def check_freeze():
    f=read(P/'freeze.json')
    for group in ['source_sha256','inputs_sha256','baseline_sha256']:
        for rel,h in f[group].items(): assert sha(P/rel)==h,rel
    check_splits(read(P/'splits.json'))
    return f

def worker(task):
    instance,split_id=task
    start=time.monotonic()
    split=read(P/'splits.json')[instance][split_id]
    original=engine.split_replicates
    def frozen_split(key,count=40):
        assert key==instance and count==40
        return {k:np.array(v,dtype=int) for k,v in split.items()}
    engine.split_replicates=frozen_split
    try:
        records,diagnostics,ledgers=engine.analyse_instance(P/'inputs'/f'{instance}.npz',config()['budgets'])
    finally: engine.split_replicates=original
    # Add labels only after the unchanged engine has finished both budgets.
    for collection in [records,diagnostics,ledgers]:
        for r in collection: r['split']=split_id
    result=dict(instance=instance,split=split_id,freeze_sha256=sha(P/'freeze.json'),
        elapsed_seconds=time.monotonic()-start,records=records,diagnostics=diagnostics,ledgers=ledgers)
    path=P/'parts'/f'{split_id}_{instance}.json'
    if path.exists(): raise FileExistsError(path)
    write(path,result)
    return path.name,result['elapsed_seconds']

def run(stage,workers):
    check_freeze();cfg=config();start=time.monotonic()
    ids=[0] if stage=='baseline' else list(range(1,21))
    if stage=='alternatives':
        assert read(P/'baseline_verification.json')['status']=='PASS'
    expected=[(i,f'S{s:03d}') for s in ids for i in cfg['instances']]
    pending=[]
    for task in expected:
        p=P/'parts'/f'{task[1]}_{task[0]}.json'
        if p.exists():
            existing=read(p);assert existing['freeze_sha256']==sha(P/'freeze.json')
            assert (existing['instance'],existing['split'])==task
        else: pending.append(task)
    (P/'parts').mkdir(exist_ok=True)
    completed=len(expected)-len(pending)
    with ProcessPoolExecutor(max_workers=workers) as pool:
        futures={pool.submit(worker,t):t for t in pending}
        for future in as_completed(futures):
            name,seconds=future.result();completed+=1
            if completed%16==0 or completed==len(expected):
                status=dict(stage=stage,completed=completed,total=len(expected),elapsed_seconds=time.monotonic()-start,last=name)
                write(P/'progress.json',status)
                print(f'{stage}: {completed}/{len(expected)} instance-splits, {status["elapsed_seconds"]:.1f}s',flush=True)
    paths=[P/'parts'/f'{s}_{i}.json' for i,s in expected]
    write(P/f'{stage}_receipt.json',dict(status='complete',timestamp_utc=now(),elapsed_seconds=time.monotonic()-start,
        workers=workers,blas_threads_per_worker=1,parts_sha256={p.name:sha(p) for p in paths}))
    if stage=='baseline': check_baseline()

def check_baseline():
    records=[];diagnostics=[];ledgers=[]
    for i in config()['instances']:
        data=read(P/'parts'/f'S000_{i}.json')
        records.extend(data['records']);diagnostics.extend(data['diagnostics']);ledgers.extend(data['ledgers'])
    keys=['instance','base_t','comparison','policy','replicate_id']
    current=pd.DataFrame(records).drop(columns='split').sort_values(keys).reset_index(drop=True)
    old=pd.read_csv(P/'baseline/outcomes.csv').sort_values(keys).reset_index(drop=True)
    pd.testing.assert_frame_equal(current[old.columns],old,check_dtype=False,check_exact=True)
    keys=keys[:-1]
    current=pd.DataFrame(ledgers).drop(columns='split').sort_values(keys).reset_index(drop=True)
    old=pd.read_csv(P/'baseline/budget_ledger.csv').sort_values(keys).reset_index(drop=True)
    pd.testing.assert_frame_equal(current[old.columns],old,check_dtype=False,check_exact=True)
    old={(x['instance'],x['base_t']):x for x in read(P/'baseline/diagnostics.json')}
    worst=0.
    for d in diagnostics:
        a=old[d['instance'],d['base_t']]
        assert d['choices']==a['choices']
        for k in ['fit_ids','select_ids','test_ids']: assert d[k]==a[k]
        for k,v in d['coefficients'].items():
            worst=max(worst,float(np.max(np.abs(np.array(v)-a['coefficients'][k]))))
    assert worst<1e-8
    write(P/'baseline_verification.json',dict(status='PASS',outcomes_exact=len(records),choices_exact=len(diagnostics)*2,
        shot_ledgers_exact=len(ledgers),maximum_coefficient_difference=worst))
    print('BASELINE PASS: all original failures, choices and shot ledgers match.',flush=True)

def summarize_rates(rates,draws):
    policies=config()['methods'];rows=[]
    mat=rates.reindex(columns=policies).to_numpy()
    boot=mat[draws].mean(axis=1)
    for j,p in enumerate(policies):
        lo,hi=np.quantile(boot[:,j],[.025,.975])
        rows.append(dict(kind='failure_rate',policy=p,reference='',estimate=float(mat[:,j].mean()),ci_low=float(lo),ci_high=float(hi)))
    k=policies.index('GRI-selector')
    for ref in ['Raw','MSE-selector','Accuracy-ZNE','Decision-ZNE']:
        j=policies.index(ref);lo,hi=np.quantile(boot[:,k]-boot[:,j],[.025,.975])
        rows.append(dict(kind='paired_difference',policy='GRI-selector',reference=ref,
            estimate=float((mat[:,k]-mat[:,j]).mean()),ci_low=float(lo),ci_high=float(hi)))
    return rows

def analyze():
    check_freeze();cfg=config()
    assert not (P/'results.json').exists(),'Do not overwrite completed analysis'
    records=[];diagnostics=[];ledgers=[]
    for stage in ['baseline','alternatives']:
        receipt=read(P/f'{stage}_receipt.json');assert receipt['status']=='complete'
        for name,h in receipt['parts_sha256'].items():
            path=P/'parts'/name;assert sha(path)==h
            d=read(path);records.extend(d['records']);diagnostics.extend(d['diagnostics']);ledgers.extend(d['ledgers'])
    outcomes=pd.DataFrame(records).sort_values(['split','instance','base_t','comparison','policy','replicate_id'])
    outcomes.to_csv(P/'outcomes.csv',index=False)
    pd.DataFrame(ledgers).to_csv(P/'budget_ledger.csv',index=False)
    write(P/'diagnostics.json',diagnostics)
    alt=outcomes[outcomes.split!='S000']
    rates=alt.groupby(['split','instance','base_t','comparison','policy'],sort=True).failure.mean().reset_index()
    rates.to_csv(P/'instance_split_rates.csv',index=False)
    draws=np.random.default_rng(cfg['bootstrap_seed']).integers(0,48,(cfg['bootstrap_replicates'],48))
    summaries=[];average=[]
    for (s,t,c),g in rates.groupby(['split','base_t','comparison'],sort=True):
        mat=g.pivot(index='instance',columns='policy',values='failure').reindex(cfg['instances'])
        summaries.extend([dict(split=s,base_t=int(t),comparison=c,**r) for r in summarize_rates(mat,draws)])
    summary=pd.DataFrame(summaries);summary.to_csv(P/'split_summary.csv',index=False)
    avg=rates.groupby(['instance','base_t','comparison','policy'],sort=True).failure.mean().reset_index()
    avg.to_csv(P/'instance_average_rates.csv',index=False)
    for (t,c),g in avg.groupby(['base_t','comparison'],sort=True):
        mat=g.pivot(index='instance',columns='policy',values='failure').reindex(cfg['instances'])
        average.extend([dict(base_t=int(t),comparison=c,**r) for r in summarize_rates(mat,draws)])
    pd.DataFrame(average).to_csv(P/'average_summary.csv',index=False)
    directions=[]
    for (t,c,ref),g in summary[summary.kind=='paired_difference'].groupby(['base_t','comparison','reference'],sort=True):
        x=g.estimate.to_numpy();primary=c=='end_to_end' and ref in ['Raw','MSE-selector']
        stable=bool(np.all(x>0)) if ref=='Raw' else bool(np.all(x<0)) if ref=='MSE-selector' else None
        directions.append(dict(base_t=int(t),comparison=c,reference=ref,minimum=float(x.min()),median=float(np.median(x)),
            maximum=float(x.max()),mean=float(x.mean()),negative=int(np.sum(x<0)),zero=int(np.sum(x==0)),positive=int(np.sum(x>0)),
            ci_below_zero=int(np.sum(g.ci_high<0)),ci_above_zero=int(np.sum(g.ci_low>0)),
            original_primary_direction_stable=stable if primary else None))
    choices=[]
    for d in diagnostics:
        if d['split']=='S000': continue
        for policy,method in d['choices'].items():
            choices.append(dict(split=d['split'],instance=d['instance'],base_t=d['base_t'],policy=policy,method=method))
    choice=pd.DataFrame(choices);choice.to_csv(P/'choices.csv',index=False)
    frequencies=choice.groupby(['base_t','policy','method']).size().rename('count').reset_index()
    frequencies['fraction']=frequencies['count']/(48*20)
    frequencies.to_csv(P/'choice_frequencies.csv',index=False)
    unstable=choice.groupby(['base_t','policy','instance']).method.nunique().gt(1).groupby(['base_t','policy']).sum()
    result=dict(status='complete',timestamp_utc=now(),alternative_splits=20,instances=48,refits=20*48*2,
        alternative_policy_decision_evaluations=len(alt),unique_original_repetitions_per_instance=40,
        split_averaged_results=average,split_sensitivity=directions,choice_frequencies=frequencies.to_dict('records'),
        instances_with_method_changes=[dict(base_t=int(t),policy=p,count=int(n)) for (t,p),n in unstable.items()],
        interpretation='Dependent retrospective repartitions, not new independent decisions or landscapes. No removal of simulation-oracle inputs.',
        manuscript_modified=False)
    write(P/'results.json',result)
    print(json.dumps({'primary':[d for d in directions if d['base_t']==512 and d['comparison']=='end_to_end'],
        'alternative_evaluations':len(alt)},indent=2),flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('stage',choices=['freeze','baseline','alternatives','analyze'])
    parser.add_argument('--workers',type=int,default=16);a=parser.parse_args()
    if a.stage=='freeze': freeze()
    elif a.stage=='analyze': analyze()
    else: run(a.stage,a.workers)
