"""Post-run numerical diagnostic, leaving every fit and policy choice unchanged."""
import runner as r
import numpy as np
from scipy.stats import norm
from sklearn.covariance import LedoitWolf

P=r.P
diagnostics=r.read(P/'diagnostics.json')
records=[]
for d in diagnostics:
    ordered=sorted((v['gri'],m) for m,v in d['scores'].items())
    if ordered[1][0]-ordered[0][0]>=1e-6: continue
    with np.load(P/'inputs'/f'{d["instance"]}.npz') as a:
        estimates=a['primitive_objective_estimates'];budgets=a['budgets'];star=int(a['x_star'])
    t=d['base_t'];sel=np.array(d['select_ids'])
    primitive=r.engine.block_mean(estimates,budgets,[(0,t)])[sel]
    raw=r.engine.block_mean(estimates,budgets,[(t,4*t)])[sel,0,:]
    values=r.engine.evaluate_methods(primitive,raw,{m:np.array(c) for m,c in d['coefficients'].items()})
    bounds={}
    for method,v in values.items():
        gaps=r.engine.gaps(v,star);gaps=gaps/np.max(np.abs(gaps))
        mean=gaps.mean(axis=0);cov=LedoitWolf().fit(gaps).covariance_
        assert np.all(np.diag(cov)>0)
        marginal=norm.sf(mean/np.sqrt(np.diag(cov)))
        bounds[method]=dict(lower=float(marginal.max()),upper=float(min(marginal.sum(),1.)))
    chosen=d['choices']['GRI-selector']
    separated=all(bounds[chosen]['upper']<bounds[m]['lower'] for m in values if m!=chosen)
    assert separated,(d['instance'],d['split'],bounds)
    records.append(dict(instance=d['instance'],split=d['split'],base_t=t,chosen=chosen,
        bounds=bounds,strict_order_separated_by_marginal_bounds=separated))
assert len(records)==1
out=P/'close_score_verification.json'
assert not out.exists()
r.write(out,dict(status='PASS',scope='Additional numerical verification after the run; not a new statistical selection rule.',
    method='For each Gaussian risk, max marginal failure <= joint failure <= sum marginal failures. The chosen method upper bound is below every competitor lower bound.',
    near_score_threshold=1e-6,records=records,original_policy_choices_unchanged=True))
print(records)
