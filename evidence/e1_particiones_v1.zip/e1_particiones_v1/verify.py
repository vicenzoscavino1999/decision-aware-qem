"""Independent integer-decision and cost replay of all E1 repartitions."""
import runner as r
from pathlib import Path
import json
import numpy as np
import pandas as pd

P=r.P

def integer_blocks(est,budgets,blocks):
    lookup={int(b):k for k,b in enumerate(budgets)}
    total=np.zeros(est.shape[:-1],dtype=np.int64)
    for lo,hi in blocks:
        total+=np.rint(hi*est[...,lookup[hi]]).astype(np.int64)
        if lo: total-=np.rint(lo*est[...,lookup[lo]]).astype(np.int64)
    return total

def failure(keys,star):
    mask=np.arange(keys.shape[1])!=star
    return np.any(keys[:,mask]<=keys[:,[star]],axis=1).astype(int)

def zne_keys(sums,coeff=None):
    if coeff is None: weights=(4,1,-2)
    else:
        n,d=float(coeff[2]).as_integer_ratio();weights=(2*d+n,-d-2*n,n)
    return sum((sums[:,k,:].astype(object)*w for k,w in enumerate(weights)),start=np.zeros(sums.shape[::2],dtype=object))

def verify():
    frozen=r.check_freeze();cfg=r.config();splits=r.read(P/'splits.json')
    # Original package hashes are an extra in-project check; a portable copy skips missing paths.
    checked_external=[]
    for name,h in frozen['protected_sha256'].items():
        if Path(name).exists(): assert r.sha(name)==h;checked_external.append(name)
    assert r.read(P/'baseline_verification.json')['status']=='PASS'
    outcomes=pd.read_csv(P/'outcomes.csv');assert len(outcomes)==403200
    diags=r.read(P/'diagnostics.json');assert len(diags)==2016
    diagnostic={(d['instance'],d['split'],d['base_t']):d for d in diags}
    actual={(i,s,int(t),c,p):g.sort_values('replicate_id') for (i,s,t,c,p),g in
            outcomes.groupby(['instance','split','base_t','comparison','policy'],sort=False)}
    choicechecks=0;checked=0;ledgerchecks=0;smallest_risk_score_gap=1.
    for instance in cfg['instances']:
        with np.load(P/'inputs'/f'{instance}.npz') as z:
            est=z['primitive_objective_estimates'];budgets=z['budgets'];ideal=z['ideal_values'];star=int(z['x_star'])
        for t in cfg['budgets']:
            primitive=integer_blocks(est,budgets,[(0,t)])
            raw=integer_blocks(est,budgets,[(t,4*t)])[:,0,:]
            rawfull=integer_blocks(est,budgets,[(t//2,8*t)])[:,0,:]
            accfull=integer_blocks(est,budgets,[(t//2,t),(2*t,4*t)])
            dafull=integer_blocks(est,budgets,[(0,2*t)])
            for split,groups in splits[instance].items():
                d=diagnostic[instance,split,t]
                for key in ['fit','select','test']: assert d[key+'_ids']==groups[key]
                test=np.array(groups['test']);sel=np.array(groups['select']);fit=np.array(groups['fit'])
                coeff=np.array(d['coefficients']['Decision-ZNE'])
                assert np.allclose([[1,1,1],[1,2,3]]@coeff,[1,0],atol=1e-8,rtol=0)
                assert d['solver_status']['status'] in ['optimal','optimal_inaccurate','all_zero_forms']
                # Verify recorded choices and selection MSE without test outcomes.
                select_values={'Raw':raw[sel]/(3*t),
                    'Accuracy-ZNE':np.einsum('s,rsc->rc',np.array([4,1,-2])/3,primitive[sel]/t),
                    'Decision-ZNE':np.einsum('s,rsc->rc',coeff,primitive[sel]/t)}
                for m,v in select_values.items():
                    mse=float(np.mean((v-ideal[None,:])**2))
                    assert np.isclose(mse,d['scores'][m]['mse'],rtol=1e-12,atol=1e-13)
                for policy,score in [('MSE-selector','mse'),('GRI-selector','gri')]:
                    chosen=min(r.engine.METHODS,key=lambda m:(d['scores'][m][score],m))
                    assert d['choices'][policy]==chosen;choicechecks+=1
                risks=sorted(x['gri'] for x in d['scores'].values())
                smallest_risk_score_gap=min(smallest_risk_score_gap,risks[1]-risks[0])
                ev={'Raw':failure(raw[test],star),'Accuracy-ZNE':failure(zne_keys(primitive[test]),star),
                    'Decision-ZNE':failure(zne_keys(primitive[test],coeff),star)}
                full={'Raw':failure(rawfull[test],star),'Accuracy-ZNE':failure(zne_keys(accfull[test]),star),
                    'Decision-ZNE':failure(zne_keys(dafull[test],coeff),star)}
                for policy,method in d['choices'].items():
                    ev[policy]=ev[method];full[policy]=ev[method]
                for c,values in [('evaluation',ev),('end_to_end',full)]:
                    for policy,expected in values.items():
                        got=actual[instance,split,t,c,policy]
                        assert got.replicate_id.tolist()==sorted(test.tolist())
                        assert np.array_equal(got.failure,expected[np.argsort(test)])
                        checked+=len(expected)
    ledgers=pd.read_csv(P/'budget_ledger.csv')
    assert len(ledgers)==20160
    for row in ledgers.itertuples():
        t=row.base_t;n=25
        fit=30*t*n if row.policy in ['Decision-ZNE','MSE-selector','GRI-selector'] else 0
        select=60*t*n if row.policy.endswith('selector') else 0
        per=3*t*n
        if row.comparison=='end_to_end':
            per=(15*t*n//2 if row.policy in ['Raw','Accuracy-ZNE'] else 6*t*n if row.policy=='Decision-ZNE' else per)
        assert (row.fit_shots,row.selection_shots,row.evaluation_shots)==(fit,select,20*per)
        assert row.total_shots_20_decisions==fit+select+20*per
        if row.comparison=='end_to_end': assert row.total_shots_20_decisions==150*n*t
        ledgerchecks+=1
    # Balanced coverage makes fixed-baseline split averages exactly their all-40 rates.
    avg=pd.read_csv(P/'instance_average_rates.csv')
    for (instance,t,c,p),g in outcomes[outcomes.policy.isin(['Raw','Accuracy-ZNE'])].groupby(['instance','base_t','comparison','policy']):
        unique=g[['replicate_id','failure']].drop_duplicates()
        assert len(unique)==40
        value=avg[(avg.instance==instance)&(avg.base_t==t)&(avg.comparison==c)&(avg.policy==p)].failure.item()
        assert np.isclose(value,unique.failure.mean(),atol=1e-14)
    summary=pd.read_csv(P/'split_summary.csv');averages=pd.read_csv(P/'average_summary.csv')
    for row in averages.itertuples():
        group=summary[(summary.base_t==row.base_t)&(summary.comparison==row.comparison)&(summary.kind==row.kind)&(summary.policy==row.policy)]
        if row.kind=='paired_difference':group=group[group.reference==row.reference]
        assert len(group)==20 and np.isclose(group.estimate.mean(),row.estimate,atol=1e-14)
    assert checked==403200 and choicechecks==4032 and ledgerchecks==20160
    result=dict(status='PASS',policy_decisions_replayed=checked,alternative_decisions=384000,
        choices_verified=choicechecks,ledger_rows_verified=ledgerchecks,disjoint_splits_and_balanced_coverage=True,
        selection_mse_recomputed=True,baseline_exact=True,split_averaging_verified=True,
        smallest_selected_vs_runnerup_gri_score_gap=smallest_risk_score_gap,
        external_protected_paths_checked=checked_external,source_and_inputs_unchanged=True,
        explanation='Exact integer evaluation reconstructed independently; the baseline replays the original fit/CDF implementation. No new independent data are inferred from repartitioning.')
    out=P/'verification.json'
    if out.exists():raise FileExistsError(out)
    r.write(out,result);print(json.dumps(result,indent=2))

if __name__=='__main__': verify()
