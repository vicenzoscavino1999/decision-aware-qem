"""Report all prespecified E1 split sensitivities without selecting favorable partitions."""
import runner as r
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

P=r.P
data=r.read(P/'results.json');assert r.read(P/'verification.json')['status']=='PASS'
summary=pd.read_csv(P/'split_summary.csv');average=pd.read_csv(P/'average_summary.csv')
original=pd.read_csv(P/'baseline/summary.csv')
fig,axes=plt.subplots(1,2,figsize=(10.2,3.7),sharex=True)
for ax,reference,title in zip(axes,['Raw','MSE-selector'],['GRI minus Raw','GRI minus MSE selection']):
    ax.axhline(0,color='.55',linewidth=.8)
    for t,color,marker in [(512,'#176b9d','o'),(1024,'#b95a22','s')]:
        selected=summary[(summary.base_t==t)&(summary.comparison=='end_to_end')&(summary.kind=='paired_difference')&(summary.reference==reference)].sort_values('split')
        ax.plot(np.arange(1,21),100*selected.estimate,color=color,marker=marker,markersize=3.5,linewidth=.8,label=f't={t}')
        old=original[(original.base_t==t)&(original.comparison=='end_to_end')&(original.kind=='paired_difference')&(original.reference==reference)].estimate.item()
        ax.axhline(100*old,color=color,linestyle='--',linewidth=.9,alpha=.8)
    ax.set_title(title);ax.set_xlabel('Balanced partition');ax.set_xticks([1,4,8,12,16,20]);ax.grid(alpha=.18)
axes[0].set_ylabel('Failure difference (percentage points)')
axes[1].legend(frameon=False)
fig.suptitle('E1 partition sensitivity at equal full shot cost')
fig.text(.5,.01,'Dashed lines: original partition. Repartitions reuse the same records.',ha='center',fontsize=9)
fig.tight_layout(rect=(0,.05,1,.95))
fig.savefig(P/'sensibilidad_particiones.png',dpi=180);fig.savefig(P/'sensibilidad_particiones.svg');plt.close(fig)

lines=['E1 — SENSIBILIDAD A LA PARTICIÓN DE AJUSTE, SELECCIÓN Y EVALUACIÓN','',
    'Se completaron las 20 particiones alternativas fijadas antes de sus resultados,',
    'con 48 instancias, ambos presupuestos y 1.920 reajustes. Se conservan los',
    'registros y métodos del análisis original; solo cambia la separación 10/10/20.',
    'Cada repetición se usa 5 veces para ajustar, 5 para seleccionar y 10 para evaluar.',
    'Las particiones son dependientes y no constituyen nuevas muestras independientes.','',
    'RESULTADOS A IGUAL COSTO TOTAL — FALLO PROMEDIADO ENTRE LAS 20 PARTICIONES']
for t in [512,1024]:
    lines.append(f'Presupuesto base t={t}; {150*25*t//20:,} shots por decisión incluyendo aprendizaje:')
    rates=average[(average.base_t==t)&(average.comparison=='end_to_end')&(average.kind=='failure_rate')]
    for p in r.config()['methods']:
        x=rates[rates.policy==p].iloc[0];lines.append(f'  {p}: {100*x.estimate:.2f}%')
    lines.append('')
lines+=['CONTRASTES CENTRALES — DIFERENCIA GRI MENOS REFERENCIA','Los rangos describen las 20 particiones; no son intervalos de confianza.']
for t in [512,1024]:
    for ref in ['Raw','MSE-selector']:
        d=next(d for d in data['split_sensitivity'] if d['base_t']==t and d['comparison']=='end_to_end' and d['reference']==ref)
        a=average[(average.base_t==t)&(average.comparison=='end_to_end')&(average.kind=='paired_difference')&(average.reference==ref)].iloc[0]
        lines += [f't={t}, GRI menos {ref}:',
          f'  Rango entre particiones: [{100*d["minimum"]:.2f}, {100*d["maximum"]:.2f}] puntos porcentuales.',
          f'  Promedio: {100*a.estimate:+.2f} puntos; intervalo descriptivo del 95% [{100*a.ci_low:.2f}, {100*a.ci_high:.2f}].',
          f'  Particiones: GRI mejor {d["negative"]}/20, empate {d["zero"]}/20, peor {d["positive"]}/20.',
          f'  Dirección original estable en las 20 particiones: {d["original_primary_direction_stable"]}.']
primary=[d for d in data['split_sensitivity'] if d['base_t']==512 and d['comparison']=='end_to_end' and d['reference'] in ['Raw','MSE-selector']]
stable=all(d['original_primary_direction_stable'] for d in primary)
lines+=['','INTERPRETACIÓN',
    ('Las dos direcciones centrales se mantienen en las 20 particiones a t=512: GRI supera a la selección por MSE, mientras Raw gana al contar todo el costo.' if stable else
     'Al menos una dirección central cambia entre particiones a t=512. El resultado original requiere una interpretación sensible a la partición; no se elige una partición favorable.'),
    'Esto evalúa estabilidad frente al reparto de los registros existentes. No',
    'elimina los valores ideales usados por el procedimiento ni demuestra',
    'transferencia a otros paisajes, ruidos o hardware.','',
    'COMPARACIÓN A IGUAL PRESUPUESTO DE EVALUACIÓN']
for t in [512,1024]:
    d=next(d for d in data['split_sensitivity'] if d['base_t']==t and d['comparison']=='evaluation' and d['reference']=='Raw')
    a=average[(average.base_t==t)&(average.comparison=='evaluation')&(average.kind=='paired_difference')&(average.reference=='Raw')].iloc[0]
    lines.append(f't={t}: GRI menos Raw promedio {100*a.estimate:+.2f} puntos, intervalo [{100*a.ci_low:.2f}, {100*a.ci_high:.2f}], rango entre particiones [{100*d["minimum"]:.2f}, {100*d["maximum"]:.2f}].')
lines+=['','INCERTIDUMBRE Y REPRODUCCIÓN',
    'Los intervalos remuestrean las 48 instancias completas, conservando juntas',
    'todas sus particiones y políticas (10.000 remuestras). Primero se promedian',
    'las particiones dentro de cada instancia. Son intervalos retrospectivos',
    'descriptivos; no se multiplicó el tamaño muestral por veinte.',
    'Las cinco permutaciones y sus rotaciones se agrupan en S001–S004, S005–S008,',
    'S009–S012, S013–S016 y S017–S020. La figura conecta valores para facilitar',
    'la lectura, sin interpretar el orden como tiempo ni las particiones como réplicas independientes.',
    'La partición original S000 se reprodujo exactamente y se excluye del promedio nuevo.',
    'Verificación independiente: 403.200 decisiones de política (384.000 alternativas),',
    '4.032 selecciones y 20.160 filas de costos. Fuentes e insumos congelados.',
    'El manuscrito v41 y el paquete v4 no se modificaron. No se publicó nada.',
    '',
    'Los resultados completos se guardan en results.json, split_summary.csv,',
    'average_summary.csv, choices.csv, diagnostics.json y outcomes.csv.',
    'Para reproducir desde cero, crear una copia de ejecución, conservar vendor/,',
    'inputs/, baseline/, protocol.json, PROTOCOLO.txt, splits.json, freeze.json y los',
    'scripts. No copiar los resultados de ejecución. Instalar requirements.txt y ejecutar:',
    '  python -B runner.py baseline --workers 16',
    '  python -B runner.py alternatives --workers 16',
    '  python -B runner.py analyze',
    '  python -B verify.py',
    '  python -B report.py',
    'Se puede reducir --workers sin cambiar las semillas. freeze.json ya contiene',
    'las particiones y los hashes; no se genera otra aleatorización. La simulación',
    'de los registros originales sigue perteneciendo al paquete v4 separado.']
(P/'INFORME.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8')
print('\n'.join(lines[:39]))
