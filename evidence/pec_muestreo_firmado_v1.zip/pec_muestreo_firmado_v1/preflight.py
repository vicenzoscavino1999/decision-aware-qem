"""Validate an exact signed-PEC law; this is not the multi-candidate study."""
import os
os.environ.setdefault('OMP_NUM_THREADS','1')
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
import sys
sys.dont_write_bytecode=True
import hashlib
import json
import time
from datetime import datetime,timezone
from pathlib import Path
import numpy as np
import networkx as nx
from qiskit import QuantumCircuit,transpile
from qiskit.circuit.library import RXGate,RZZGate
from qiskit.quantum_info import DensityMatrix,Statevector,Pauli,SuperOp
from qiskit_aer import AerSimulator
from qiskit_aer.noise import depolarizing_error

P=Path(__file__).resolve().parent
ROOT=P.parent.parent
CODE=ROOT/'outputs/reproduccion_plan_v4/paquete/code/src'
sys.path.insert(0,str(CODE))
from daqem.pec import inverse_depolarizing_quasiprobabilities,sampled_pec_circuit,circuit_gamma
from daqem.noise import depolarizing_noise_model
from daqem.qaoa import qaoa_maxcut_circuit


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def combined_absolute_channel(p,n):
    """Depolarizing probability after noise and absolute-weight corrections."""
    inv=inverse_depolarizing_quasiprobabilities(p,n)
    identity='I'*n
    nonid=[v for k,v in inv.sampling_probabilities.items() if k!=identity]
    assert np.ptp(nonid)<1e-14
    p_abs=(4**n)*float(np.mean(nonid))
    return 1-(1-p)*(1-p_abs),inv


def enumerate_check():
    """Explicit sum of all 4*16 branch density matrices, no sampling error."""
    initial=QuantumCircuit(2);initial.h(0);initial.ry(0.47,1);initial.cx(0,1)
    rho=DensityMatrix.from_instruction(initial)
    p1,p2=0.013,0.037
    pc1,i1=combined_absolute_channel(p1,1)
    pc2,i2=combined_absolute_channel(p2,2)
    U1=RXGate(.39);U2=RZZGate(.71)
    first=rho.evolve(U1,[0]).evolve(SuperOp(depolarizing_error(p1,1)),[0])
    sums={1:np.zeros((4,4),complex),-1:np.zeros((4,4),complex)}
    for label1,q1 in i1.quasi_probabilities.items():
        r1=first.evolve(Pauli(label1),[0])
        r2=r1.evolve(U2,[0,1]).evolve(SuperOp(depolarizing_error(p2,2)),[0,1])
        for label2,q2 in i2.quasi_probabilities.items():
            branch=r2.evolve(Pauli(label2),[0,1]).data
            sign=1 if q1*q2>=0 else -1
            sums[sign]+=abs(q1*q2)/(i1.gamma*i2.gamma)*branch
    ideal=rho.evolve(U1,[0]).evolve(U2,[0,1]).data
    absolute=rho.evolve(U1,[0]).evolve(SuperOp(depolarizing_error(pc1,1)),[0])
    absolute=absolute.evolve(U2,[0,1]).evolve(SuperOp(depolarizing_error(pc2,2)),[0,1]).data
    gamma=i1.gamma*i2.gamma
    errors=[float(np.max(np.abs(sums[s]-(absolute+s*ideal/gamma)/2))) for s in [1,-1]]
    assert max(errors)<1e-12,errors
    return dict(branches=64,positive_negative_sector_max_error=max(errors),gamma=gamma)


def probabilities(circuit,p1,p2):
    sim=AerSimulator(method='density_matrix',noise_model=depolarizing_noise_model(p1,p2),max_parallel_threads=1,max_parallel_experiments=1)
    c=transpile(circuit,basis_gates=['h','rx','rzz'],optimization_level=0,seed_transpiler=70251)
    c.save_probabilities()
    p=np.asarray(sim.run(c).result().data(0)['probabilities'],float)
    assert p.min()>-1e-14 and abs(p.sum()-1)<1e-12
    p=np.maximum(p,0);return p/p.sum()


def main():
    if (P/'preflight.json').exists(): raise RuntimeError('Do not overwrite the technical run')
    protected=[ROOT/'outputs/revision_v40/manuscript/main.tex',ROOT/'outputs/revision_v40/decision_residual_fields_theory_v40.pdf',
        ROOT/'outputs/reproduccion_plan_v4/paquete_reproduccion_v4.zip',ROOT/'outputs/prueba_zne_viabilidad_v1.zip',ROOT/'outputs/prueba_zne_final_v2.zip']
    before={str(f):sha(f) for f in protected}
    imported=['pec.py','noise.py','qaoa.py','candidates.py','risk.py','budget.py','rng.py','__init__.py']
    receipt=dict(timestamp_utc=datetime.now(timezone.utc).isoformat(),code_sha256=sha(__file__),plan_sha256=sha(P/'PLAN.txt'),
                 imported_sha256={n:sha(CODE/'daqem'/n) for n in imported},protected_sha256=before,
                 seed=2026102323,explicit_circuits=2048,shots_per_circuit=1)
    (P/'preflight_freeze.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
    start=time.monotonic()
    algebra=enumerate_check()
    graph=nx.cycle_graph(4);m=graph.number_of_edges()
    g=[.63];b=[.29];p1=.01;p2=.03
    circuit=qaoa_maxcut_circuit(graph,depth=1,gammas=g,betas=b,measure=False)
    ideal=Statevector.from_instruction(circuit).probabilities()
    pc1,inv1=combined_absolute_channel(p1,1);pc2,inv2=combined_absolute_channel(p2,2)
    absolute=probabilities(circuit,pc1,pc2)
    gamma=circuit_gamma(graph,depth=1,gammas=g,betas=b,p1=p1,p2=p2)
    joint=np.stack([(absolute+ideal/gamma)/2,(absolute-ideal/gamma)/2])
    assert joint.min()>-1e-13 and abs(joint.sum()-1)<1e-12
    joint=np.maximum(joint,0);joint/=joint.sum()
    cuts=np.array([sum(((s>>a)&1)!=((s>>bb)&1) for a,bb in graph.edges) for s in range(16)])
    h=m/2-cuts
    signed_values=np.stack([gamma*h,-gamma*h])
    expected=float(np.sum(joint*signed_values))
    variance=float(np.sum(joint*signed_values**2)-expected**2)
    exact=float(ideal@h)
    assert abs(expected-exact)<1e-12
    rng=np.random.default_rng(receipt['seed']);circuits=[];signs=[]
    for _ in range(receipt['explicit_circuits']):
        c,s,gg=sampled_pec_circuit(graph,depth=1,gammas=g,betas=b,inverse_1q=inv1,inverse_2q=inv2,rng=rng)
        assert abs(gg-gamma)<1e-12
        circuits.append(c);signs.append(s)
    sim=AerSimulator(noise_model=depolarizing_noise_model(p1,p2),method='density_matrix',seed_simulator=2026102324,
                     max_parallel_threads=1,max_parallel_experiments=1)
    result=sim.run(circuits,shots=1).result()
    assert result.success
    states=np.array([int(next(iter(result.get_counts(k))).replace(' ',''),2) for k in range(len(circuits))])
    signs=np.asarray(signs,dtype=int)
    observed=gamma*signs*h[states]
    error=float(observed.mean()-exact)
    se=float(np.sqrt(variance/len(observed)))
    z=abs(error)/se
    negative_expected=float(joint[1].sum())
    negative_observed=float(np.mean(signs<0))
    neg_se=np.sqrt(negative_expected*(1-negative_expected)/len(signs))
    neg_z=abs(negative_observed-negative_expected)/neg_se
    assert z<5 and neg_z<5,(z,neg_z)
    np.savez_compressed(P/'explicit_circuit_records.npz',sign=signs,state=states,centered_signed_value=observed,
                         exact_joint_sign_state=joint,ideal_probabilities=ideal,absolute_probabilities=absolute)
    assert all(sha(f)==v for f,v in before.items())
    data=dict(status='PASS',scope='Technical validation only; multi-candidate MSE/decision experiment not run yet.',
        algebra=algebra,explicit_circuits=len(circuits),shots_per_circuit=1,actual_shots=len(circuits),
        gamma=gamma,gamma_squared=gamma**2,centered_ideal_mean=exact,centered_empirical_pec_mean=float(observed.mean()),
        absolute_mean_error=abs(error),predicted_standard_error=se,mean_error_in_standard_errors=z,
        negative_sign_probability=negative_expected,empirical_negative_fraction=negative_observed,negative_error_in_standard_errors=float(neg_z),
        exact_signed_variance_per_shot=variance,constant_offset_added_exactly=-m/2,
        elapsed_seconds=time.monotonic()-start,protected_files_unchanged=True,
        receipt_sha256=sha(P/'preflight_freeze.json'),timestamp_utc=datetime.now(timezone.utc).isoformat())
    (P/'preflight.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(data,indent=2))


if __name__=='__main__':main()
