"""Exact signed-PEC model, independent-shot decisions and risk calculations."""
import os
os.environ.setdefault('OMP_NUM_THREADS','1')
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
os.environ.setdefault('MKL_NUM_THREADS','1')
import sys
sys.dont_write_bytecode=True
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent/'vendor'))
import numpy as np
from scipy.fft import rfft,irfft,next_fast_len
from scipy.integrate import quad
from scipy.special import ndtr
from qiskit import transpile
from qiskit.quantum_info import Statevector
from qiskit_aer import AerSimulator
from daqem.noise import depolarizing_noise_model
from daqem.pec import inverse_depolarizing_quasiprobabilities,circuit_gamma
from daqem.qaoa import qaoa_maxcut_circuit


def absolute_channel(p,n):
    if not 0<=p<1: raise ValueError('This control assumes 0<=p<1')
    inv=inverse_depolarizing_quasiprobabilities(p,n)
    nonid=[v for k,v in inv.sampling_probabilities.items() if k!='I'*n]
    if np.ptp(nonid)>1e-12: raise ValueError('Expected uniform nonidentity Paulis')
    p_abs=4**n*float(np.mean(nonid))
    return 1-(1-p)*(1-p_abs),inv.gamma


def physical_probabilities(circuits,p1,p2):
    sim=AerSimulator(method='density_matrix',noise_model=depolarizing_noise_model(p1,p2),
                     max_parallel_threads=1,max_parallel_experiments=1)
    compiled=transpile(circuits,basis_gates=['h','rx','rzz'],optimization_level=0,seed_transpiler=77231)
    for source,target in zip(circuits,compiled,strict=True):
        if source.count_ops()!=target.count_ops(): raise RuntimeError('Gate decomposition changed')
        target.save_probabilities()
    result=sim.run(compiled).result()
    if not result.success: raise RuntimeError('Aer failed')
    p=np.asarray([result.data(i)['probabilities'] for i in range(len(compiled))],float)
    if p.min() < -1e-14 or np.max(np.abs(p.sum(-1)-1))>1e-11: raise RuntimeError('Invalid probabilities')
    p=np.maximum(p,0);return p/p.sum(-1,keepdims=True)


def primitive_laws(graph,angles,depth,p1,p2):
    m=graph.number_of_edges();n=graph.number_of_nodes()
    circuits=[qaoa_maxcut_circuit(graph,depth=depth,gammas=a[:depth],betas=a[depth:],measure=False) for a in angles]
    cuts=np.array([sum(((s>>a)&1)!=((s>>b)&1) for a,b in graph.edges) for s in range(2**n)])
    ideal=np.array([Statevector.from_instruction(c).probabilities() for c in circuits])
    raw=physical_probabilities(circuits,p1,p2)
    pc1,g1=absolute_channel(p1,1);pc2,g2=absolute_channel(p2,2)
    absolute=physical_probabilities(circuits,pc1,pc2)
    gammas=np.array([circuit_gamma(graph,depth=depth,gammas=a[:depth],betas=a[depth:],p1=p1,p2=p2) for a in angles])
    gamma=g1**(n*(depth+1))*g2**(m*depth)
    if not np.allclose(gammas,gamma,rtol=1e-12): raise RuntimeError('Gamma differs among candidates')
    joint=np.stack([(absolute+ideal/gamma)/2,(absolute-ideal/gamma)/2],axis=1)
    minimum=float(joint.min())
    if minimum < -1e-12: raise RuntimeError('Signed law not positive')
    joint=np.maximum(joint,0);joint/=joint.sum(axis=(1,2),keepdims=True)
    raw_cut=np.array([np.bincount(cuts,weights=p,minlength=m+1) for p in raw])
    ideal_cut=np.array([np.bincount(cuts,weights=p,minlength=m+1) for p in ideal])
    joint_cut=np.array([[np.bincount(cuts,weights=p,minlength=m+1) for p in j] for j in joint])
    return dict(raw_state=raw,ideal_state=ideal,absolute_state=absolute,joint_state=joint,
                raw_cut=raw_cut,ideal_cut=ideal_cut,joint_cut=joint_cut,cuts=cuts,gamma=gamma,
                minimum_joint_probability_before_roundoff_clip=minimum)


def centered_moments(p,values):
    p=np.asarray(p,float);values=np.asarray(values,float)
    mean=p@values
    c=values[None,:]-mean[:,None]
    return mean,np.stack([np.sum(p*c**k,axis=-1) for k in [2,3,4]],axis=-1)


def mse_expectation_and_sampling_se(mean,moments,truth,B,R):
    b=mean-truth;v,mu3,mu4=moments.T
    mse=b*b+v/B
    fourth=b**4+6*b*b*v/B+4*b*mu3/B**2+3*v*v/B**2+(mu4-3*v*v)/B**3
    # Candidate means are independently measured. This includes non-Gaussian fourth moments.
    variance=float(np.maximum(fourth-mse*mse,0).sum()/len(mean)**2/R)
    return float(mse.mean()),float(np.sqrt(variance))


def gaussian_failure(mean,variance,reference):
    mean=np.asarray(mean,float);v=np.asarray(variance,float)
    if np.any(v<=0): raise ValueError('Positive variances required by this quadrature')
    sd=np.sqrt(v);others=np.arange(len(mean))!=reference
    def integrand(z):
        return np.exp(-z*z/2)/np.sqrt(2*np.pi)*np.prod(ndtr((mean[others]-mean[reference]-sd[reference]*z)/sd[others]))
    success,error=quad(integrand,-10,10,epsabs=1e-10,epsrel=1e-10,limit=250)
    if error>1e-7: raise RuntimeError('Gaussian quadrature did not converge')
    return float(np.clip(1-success,0,1)),float(error)


def discrete_failure(single_shot_statistic,B,reference,padding_multiplier=1):
    """Numerical B-fold convolution, strict maximum of nonnegative integer sums."""
    p=np.asarray(single_shot_statistic,float)
    if p.ndim!=2 or np.any(p<0) or not np.allclose(p.sum(-1),1,atol=1e-12): raise ValueError('Invalid pmf')
    degree=p.shape[1]-1;length=B*degree+1
    nfft=next_fast_len(length)*padding_multiplier
    full=irfft(rfft(p,n=nfft,axis=1,workers=1)**B,n=nfft,axis=1,workers=1)
    mass_error=float(np.max(np.abs(full.sum(-1)-1)))
    negative_mass=float(np.max(-np.minimum(full,0).sum(-1)))
    outside_mass=float(np.max(np.abs(full[:,length:]).sum(-1))) if length<nfft else 0.
    if max(mass_error,negative_mass,outside_mass)>1e-8: raise RuntimeError('Convolution precision check failed')
    pmf=np.maximum(full[:,:length],0);pmf/=pmf.sum(-1,keepdims=True)
    less=np.concatenate([np.zeros((len(p),1)),np.cumsum(pmf,axis=1)[:,:-1]],axis=1)
    others=np.arange(len(p))!=reference
    success=float(np.sum(pmf[reference]*np.prod(less[others],axis=0)))
    return float(np.clip(1-success,0,1)),dict(nfft=nfft,negative_mass=negative_mass,mass_error=mass_error,outside_mass=outside_mass)


def strict_winners_max(integer_sums):
    sums=np.asarray(integer_sums)
    maximum=sums.max(-1)
    winner=sums.argmax(-1).astype(np.int16)
    winner[np.sum(sums==maximum[...,None],axis=-1)!=1]=-1
    return winner
