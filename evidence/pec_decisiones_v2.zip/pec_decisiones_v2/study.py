"""Frozen signed-PEC study: freeze, laws, sampling, analysis; no paper edits."""
import sys
sys.dont_write_bytecode=True
import argparse
import csv
import hashlib
import importlib.metadata
import json
import time
from datetime import datetime,timezone
from pathlib import Path
import model
import numpy as np
import networkx as nx
from daqem.qaoa import default_angles

P=Path(__file__).resolve().parent
ROOT=P.parent.parent


def read(path): return json.loads(Path(path).read_text(encoding='utf-8'))
def write(path,data):
    Path(path).parent.mkdir(parents=True,exist_ok=True)
    Path(path).write_text(json.dumps(data,indent=2,ensure_ascii=False,allow_nan=False)+'\n',encoding='utf-8')
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def now(): return datetime.now(timezone.utc).isoformat()
def config(): return read(P/'protocol.json')
def rng_for(*args):
    h=hashlib.sha256('|'.join(map(str,args)).encode()).digest()
    return np.random.default_rng(int.from_bytes(h[:16],'big'))
def csv_write(path,rows):
    with Path(path).open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)


def freeze():
    if (P/'freeze.json').exists(): raise RuntimeError('Already frozen')
    cfg=config();g,b=default_angles(cfg['depth']);base=np.r_[g,b];manifest=[]
    for j in range(cfg['landscapes']):
        key=f'PS{j+1:03d}';rng=rng_for(cfg['seed'],key,'blind_landscape')
        graph_seed=int(rng.integers(1,2**31-1))
        graph=nx.random_regular_graph(cfg['degree'],cfg['qubits'],seed=graph_seed)
        center=base+rng.uniform(-cfg['center_jitter'],cfg['center_jitter'],len(base))
        offsets=[np.zeros(len(base))]
        for k in range(len(base)):
            d=np.eye(len(base))[k]*cfg['local_radius'];offsets.extend([d,-d])
        angles=(center+np.array(offsets))[rng.permutation(cfg['candidates'])]
        manifest.append(dict(id=key,graph_seed=graph_seed,edges=sorted(sorted(e) for e in graph.edges),angles=angles.tolist()))
    write(P/'landscapes.json',manifest)
    protected=[ROOT/'outputs/revision_v40/manuscript/main.tex',ROOT/'outputs/revision_v40/decision_residual_fields_theory_v40.pdf',
        ROOT/'outputs/reproduccion_plan_v4/paquete_reproduccion_v4.zip',ROOT/'outputs/prueba_zne_viabilidad_v1.zip',
        ROOT/'outputs/prueba_zne_final_v2.zip',ROOT/'outputs/pec_muestreo_firmado_v1.zip']
    source=['model.py','study.py','verify.py','report.py','protocol.json','PROTOCOLO.txt','landscapes.json']
    source += [str(f.relative_to(P)).replace('\\','/') for f in sorted((P/'vendor').rglob('*.py'))]
    versions={k:importlib.metadata.version(k) for k in ['numpy','scipy','networkx','qiskit','qiskit-aer','PyYAML','matplotlib']}
    write(P/'freeze.json',dict(timestamp_utc=now(),source_sha256={s:sha(P/s) for s in source},
        protected_sha256={str(f):sha(f) for f in protected},versions=versions,python=sys.version,
        earlier_signed_law_validation=read(ROOT/'outputs/pec_muestreo_firmado_v1/preflight.json'),
        note='Local pre-outcome freeze, not an external preregistration.'))
    (P/'requirements.txt').write_text('\n'.join(f'{k}=={v}' for k,v in versions.items())+'\n',encoding='utf-8')
    print('FROZEN protocol, blind candidate manifest, sources and protected-file hashes',flush=True)


def check_freeze(protected=True):
    frozen=read(P/'freeze.json')
    for rel,h in frozen['source_sha256'].items():
        if sha(P/rel)!=h: raise RuntimeError(f'Frozen source changed: {rel}')
    if protected:
        for name,h in frozen['protected_sha256'].items():
            if sha(name)!=h: raise RuntimeError(f'Protected file changed: {name}')
    return frozen


def laws():
    check_freeze();cfg=config();start=time.monotonic();out=P/'laws';out.mkdir(exist_ok=True)
    for item in read(P/'landscapes.json'):
        graph=nx.Graph();graph.add_nodes_from(range(cfg['qubits']));graph.add_edges_from(item['edges'])
        for noise in cfg['noise']:
            path=out/f"{item['id']}_{noise['name']}.npz"
            if path.exists():raise RuntimeError('Do not overwrite laws')
            law=model.primitive_laws(graph,np.array(item['angles']),cfg['depth'],noise['p1'],noise['p2'])
            np.savez_compressed(path,**law)
            print('LAWS',path.stem,f'{time.monotonic()-start:.2f}s',flush=True)
    write(P/'laws_receipt.json',dict(timestamp_utc=now(),elapsed_seconds=time.monotonic()-start,
        sha256={f.name:sha(f) for f in sorted(out.glob('*.npz'))}))


def sample():
    check_freeze();cfg=config();R=cfg['repetitions'];start=time.monotonic()
    out=P/'records';out.mkdir(exist_ok=True)
    receipt=read(P/'laws_receipt.json')
    for name,h in receipt['sha256'].items():
        if sha(P/'laws'/name)!=h:raise RuntimeError('Law changed')
        with np.load(P/'laws'/name) as z:
            raw=z['raw_cut'];joint=z['joint_cut'];gamma=float(z['gamma'])
        n,m1=raw.shape;m=m1-1;k=np.arange(m1,dtype=np.int64)
        for B in cfg['budgets_per_candidate']:
            target=out/f'{Path(name).stem}_B{B}.npz'
            if target.exists():raise RuntimeError('Do not overwrite records')
            raw_rng=rng_for(cfg['seed'],Path(name).stem,B,'Raw')
            pec_rng=rng_for(cfg['seed'],Path(name).stem,B,'Signed-PEC')
            rc=np.stack([raw_rng.multinomial(B,p,size=R) for p in raw],axis=1)
            pc=np.stack([pec_rng.multinomial(B,p.ravel(),size=R).reshape(R,2,m1) for p in joint],axis=1)
            raw_sums=rc@k
            pec_sums=pc[:,:,0]@k+pc[:,:,1]@(m-k)
            raw_est=-raw_sums/B
            pec_est=-m/2+gamma*(m/2-pec_sums/B)
            decisions=np.stack([model.strict_winners_max(raw_sums),model.strict_winners_max(pec_sums)],axis=1)
            np.savez_compressed(target,raw_counts=rc,pec_joint_counts=pc,raw_integer_statistic=raw_sums,
                pec_integer_statistic=pec_sums,raw_estimates=raw_est,pec_estimates=pec_est,winners=decisions)
    write(P/'sampling_receipt.json',dict(timestamp_utc=now(),elapsed_seconds=time.monotonic()-start,
        files_sha256={f.name:sha(f) for f in sorted(out.glob('*.npz'))},
        simulation='Exact marginal of independently redrawn signed circuit branches; no hardware execution.'))
    print('SAMPLING complete',f'{time.monotonic()-start:.2f}s',flush=True)


def analyze():
    check_freeze();cfg=config();start=time.monotonic();rows=[];proxy_rows=[];precision=[]
    rec=read(P/'sampling_receipt.json');laws_receipt=read(P/'laws_receipt.json')
    for name,h in rec['files_sha256'].items():
        if sha(P/'records'/name)!=h:raise RuntimeError('Record changed')
    if (P/'results.json').exists():raise RuntimeError('Do not overwrite results')
    for name,h in laws_receipt['sha256'].items():
        if sha(P/'laws'/name)!=h:raise RuntimeError('Law changed')
        cell=Path(name).stem;landscape,noise=cell.split('_',1)
        with np.load(P/'laws'/name) as z:
            raw=z['raw_cut'];ideal=z['ideal_cut'];joint=z['joint_cut'];gamma=float(z['gamma'])
        n,m1=raw.shape;m=m1-1;k=np.arange(m1)
        truth=ideal@(-k);star=int(np.argmin(truth))
        if np.sort(truth)[1]-truth[star] <= 1e-10: raise RuntimeError('Nonunique ideal minimizer; no silent exclusion')
        raw_mean,raw_mom=model.centered_moments(raw,-k)
        pec_values=(-m/2+gamma*np.stack([m/2-k,-(m/2-k)])).ravel()
        pec_mean,pec_mom=model.centered_moments(joint.reshape(n,-1),pec_values)
        ideal_mean,ideal_mom=model.centered_moments(ideal,-k)
        if np.max(np.abs(pec_mean-truth))>1e-11:raise RuntimeError('PEC is not unbiased in its stipulated exact model')
        # Both decision keys are strict MAXIMA of integer sums in [0,m].
        # For negative sign, PEC statistic is m-cut; this preserves all ties.
        pec_stat=joint[:,0,:]+joint[:,1,::-1]
        for B in cfg['budgets_per_candidate']:
            with np.load(P/'records'/f'{cell}_B{B}.npz') as d:
                estimators=[d['raw_estimates'],d['pec_estimates']]
                winners=d['winners']
            for mi,(method,pmf,mean,mom,estimates) in enumerate(zip(cfg['methods'],[raw,pec_stat],
                    [raw_mean,pec_mean],[raw_mom,pec_mom],estimators,strict=True)):
                mse,se=model.mse_expectation_and_sampling_se(mean,mom,truth,B,cfg['repetitions'])
                empirical_mse=float(np.mean((estimates-truth)**2))
                failure=float(np.mean(winners[:,mi]!=star))
                ties=float(np.mean(winners[:,mi]<0))
                finite,diag=model.discrete_failure(pmf,B,star)
                gri,err=model.gaussian_failure(mean,mom[:,0]/B,star)
                fail_se=float(np.sqrt(finite*(1-finite)/cfg['repetitions']))
                rows.append(dict(landscape=landscape,noise=noise,budget=B,method=method,gamma_squared=gamma**2,
                    mse_expected=mse,mse_empirical=empirical_mse,mse_empirical_se=se,
                    failure_discrete=finite,failure_empirical=failure,failure_empirical_se=fail_se,
                    risk_gaussian=gri,gaussian_abs_error=abs(gri-finite),tie_rate=ties,
                    total_shots_per_decision=B*n,shots_per_candidate=B,independent_branch_per_shot=True,
                    ideal_gap=float(np.sort(truth)[1]-truth[star])))
                precision.append(dict(cell=cell,budget=B,method=method,gaussian_quadrature_error=err,**diag))
            n_eff=int(np.floor(B/(gamma**2)))
            if n_eff<1:raise RuntimeError('Proxy has zero effective samples')
            prisk,pdiag=model.discrete_failure(ideal,n_eff,star)
            pgri,_=model.gaussian_failure(ideal_mean,ideal_mom[:,0]/n_eff,star)
            ratio=(pec_mom[:,0]/B)/(ideal_mom[:,0]/n_eff)
            proxy_rows.append(dict(landscape=landscape,noise=noise,budget=B,effective_samples=n_eff,
                mse_proxy=float(np.mean(ideal_mom[:,0]/n_eff)),failure_discrete_proxy=prisk,risk_gaussian_proxy=pgri,
                actual_to_proxy_variance_ratio_mean=float(ratio.mean()),actual_to_proxy_variance_ratio_min=float(ratio.min()),
                actual_to_proxy_variance_ratio_max=float(ratio.max())))
        print('ANALYZED',cell,f'{time.monotonic()-start:.1f}s',flush=True)
    csv_write(P/'cell_results.csv',rows);csv_write(P/'proxy_diagnostic.csv',proxy_rows)
    write(P/'numerical_precision.json',precision)
    aggregate={}
    for B in cfg['budgets_per_candidate']:
        clusters=[];signatures=0;emp_signatures=0
        for item in read(P/'landscapes.json'):
            group=[r for r in rows if r['landscape']==item['id'] and r['budget']==B]
            per_method={m:{k:float(np.mean([r[k] for r in group if r['method']==m])) for k in
                ['mse_expected','mse_empirical','failure_discrete','failure_empirical','risk_gaussian']} for m in cfg['methods']}
            clusters.append([per_method[m][k] for m in cfg['methods'] for k in
                ['mse_expected','mse_empirical','failure_discrete','failure_empirical','risk_gaussian']])
            for no in cfg['noise']:
                a=next(r for r in group if r['method']=='Raw' and r['noise']==no['name'])
                b=next(r for r in group if r['method']=='Signed-PEC' and r['noise']==no['name'])
                signatures+=int(b['mse_expected']<a['mse_expected']-1e-12 and b['failure_discrete']>a['failure_discrete']+1e-6)
                emp_signatures+=int(b['mse_empirical']<a['mse_empirical'] and b['failure_empirical']>a['failure_empirical'])
        c=np.asarray(clusters);dif=c[:,5:]-c[:,:5]
        idx=rng_for(cfg['seed'],B,'cluster_bootstrap').integers(0,len(c),(cfg['bootstrap']['replicates'],len(c)))
        boot=dif[idx].mean(1);cis=np.quantile(boot,[.05,.95],axis=0)
        keys=['mse_expected','mse_empirical','failure_discrete','failure_empirical','risk_gaussian']
        aggregate[str(B)]=dict(Raw=dict(zip(keys,c[:,:5].mean(0).tolist())),PEC=dict(zip(keys,c[:,5:].mean(0).tolist())),
            differences_pec_minus_raw=dict(zip(keys,dif.mean(0).tolist())),
            differences_90ci={k:cis[:,i].tolist() for i,k in enumerate(keys)},
            signature_cells_model=signatures,signature_cells_empirical=emp_signatures,total_cells=cfg['landscapes']*len(cfg['noise']))
    primary=aggregate[str(cfg['primary_budget'])];d=primary['differences_pec_minus_raw'];ci=primary['differences_90ci']
    directions=d['mse_expected']< -1e-12 and d['failure_discrete']>1e-6 and d['mse_empirical']<0 and d['failure_empirical']>0
    supported=directions and ci['mse_empirical'][1]<0 and ci['failure_empirical'][0]>0
    status='SUPPORTED_IN_EXPLORATORY_PILOT' if supported else 'DIRECTION_ONLY' if directions else 'NOT_SUPPORTED_AT_PRIMARY_BUDGET'
    gaussian={m:dict(mean_abs_error=float(np.mean([r['gaussian_abs_error'] for r in rows if r['method']==m])),
        max_abs_error=float(np.max([r['gaussian_abs_error'] for r in rows if r['method']==m]))) for m in cfg['methods']}
    for item in gaussian.values():
        item['within_prespecified_descriptive_thresholds']=bool(item['mean_abs_error']<=.02 and item['max_abs_error']<=.05)
    write(P/'results.json',dict(timestamp_utc=now(),elapsed_seconds=time.monotonic()-start,
        primary_budget=cfg['primary_budget'],primary_signature_status=status,aggregate=aggregate,
        gaussian_adequacy=gaussian,manuscript_modified=False,
        scope='Exploratory eight-landscape stationary known-noise simulation; centered signed observable, ideal corrections.'))
    print(json.dumps(dict(status=status,aggregate=aggregate,gaussian_adequacy=gaussian),indent=2),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('stage',choices=['freeze','laws','sample','analyze'])
    {'freeze':freeze,'laws':laws,'sample':sample,'analyze':analyze}[parser.parse_args().stage]()
