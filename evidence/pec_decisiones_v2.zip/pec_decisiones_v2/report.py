"""Human-readable report and standalone figure; never edits the manuscript."""
import sys
sys.dont_write_bytecode=True
import csv
import json
import zipfile
from pathlib import Path
import numpy as np
import study


def main():
    P=study.P;study.check_freeze();cfg=study.config();r=study.read(P/'results.json')
    assert study.read(P/'verification_post.json')['status']=='PASS'
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    budgets=cfg['budgets_per_candidate'];agg=r['aggregate'];primary=agg[str(cfg['primary_budget'])]
    rows=[]
    for B in budgets:
        a=agg[str(B)]
        rows.append(f"{B:>6}   {a['Raw']['mse_expected']:11.6f} {a['PEC']['mse_expected']:11.6f}    "
                    f"{100*a['Raw']['failure_empirical']:6.2f}% {100*a['PEC']['failure_empirical']:6.2f}%    "
                    f"{a['signature_cells_model']:2d}/16")
    table='\n'.join(rows)
    d=primary['differences_pec_minus_raw'];ci=primary['differences_90ci']
    proxy=list(csv.DictReader((P/'proxy_diagnostic.csv').open(encoding='utf-8')))
    ratios=[float(x['actual_to_proxy_variance_ratio_mean']) for x in proxy]
    gaussian=r['gaussian_adequacy']
    status=r['primary_signature_status']
    if status=='SUPPORTED_IN_EXPLORATORY_PILOT':
        conclusion='La separación MSE-decisión obtiene apoyo en la comparación principal de este piloto. Merece considerar una incorporación compacta como evidencia adicional, tras revisar su encaje y las limitaciones; no se ha incorporado automáticamente.'
    elif status=='DIRECTION_ONLY':
        conclusion='Las direcciones medias coinciden con la separación buscada, pero los intervalos no cumplen el criterio previo. Es evidencia exploratoria limitada, no una confirmación suficiente para ampliar el paper.'
    else:
        conclusion='La comparación principal no respalda la separación bajo el criterio fijado. No cambiar las semillas o el presupuesto principal para presentar una confirmación que este piloto no dio.'
    fig,axes=plt.subplots(1,2,figsize=(11,4.3),layout='constrained')
    for method,label,color in [('Raw','Raw','#195fa8'),('PEC','PEC firmado','#b05b15')]:
        mse=[agg[str(B)][method]['mse_expected'] for B in budgets]
        empirical=[agg[str(B)][method]['mse_empirical'] for B in budgets]
        finite=[agg[str(B)][method]['failure_discrete'] for B in budgets]
        observed=[agg[str(B)][method]['failure_empirical'] for B in budgets]
        axes[0].plot(budgets,mse,color=color,label=label,lw=2)
        axes[0].scatter(budgets,empirical,color=color,s=36,zorder=3)
        axes[1].plot(budgets,np.array(finite)*100,color=color,label=label,lw=2)
        axes[1].scatter(budgets,np.array(observed)*100,color=color,s=36,zorder=3)
    axes[0].set_yscale('log');axes[0].set_ylabel('MSE medio');axes[0].set_title('Error de estimación')
    axes[1].set_ylabel('Decisiones incorrectas (%)');axes[1].set_title('Error de decisión')
    for ax in axes:
        ax.set_xscale('log');ax.set_xticks(budgets,[str(B) for B in budgets]);ax.set_xlabel('Shots por candidato (mismo costo)')
        ax.grid(alpha=.2);ax.legend(frameon=False)
        ax.axvline(cfg['primary_budget'],color='#888888',lw=.8,ls=':',zorder=0)
    fig.suptitle('PEC con contribuciones firmadas · 8 paisajes y 2 ruidos\nLíneas: modelo a presupuesto finito; puntos: simulación',fontsize=12)
    fig.savefig(P/'comparacion_pec.png',dpi=180)
    fig.savefig(P/'comparacion_pec.svg');plt.close(fig)
    report=f'''PEC FIRMADO — RESULTADOS DEL ESTUDIO EXPLORATORIO
23 de octubre de 2026, America/Lima.

ESTADO DE LA COMPARACIÓN PRINCIPAL: {status}
{conclusion}

1. QUÉ SE EJECUTÓ
Ocho paisajes nuevos y ciegos de QAOA/MaxCut, seis qubits, profundidad dos,
nueve candidatos, dos ruidos y tres presupuestos. 512 repeticiones por
celda y presupuesto; 24.576 decisiones por método y 49.152 entre ambos.
No se buscaron ni ordenaron candidatos usando sus valores ideales.
Semillas, fuentes y criterios quedaron congelados antes de los resultados.

La simulación conserva la ley conjunta exacta del signo y resultado de PEC,
marginalizando las ramas del circuito. Esa ley fue contrastada previamente
con 64 ramas enumeradas y 2.048 circuitos PEC explícitos. Esta nueva campaña
muestrea su ley marginal: no ejecuta explícitamente un circuito por cada
shot simulado ni usa floor(B/Gamma^2) muestras ideales como sustituto.

La parte constante del Hamiltoniano se suma exactamente, fuera del peso
firmado. Cada shot representa una rama independiente. No hay estimación
del canal: se supone conocido y las correcciones Pauli son ideales.

2. RESULTADOS AGREGADOS — MENOR ES MEJOR EN AMBAS MÉTRICAS
     B      MSE Raw     MSE PEC       Fallo Raw Fallo PEC   Separación
{table}

MSE de la tabla: esperanza finita calculada con sesgo y varianza reales.
Fallo: frecuencia observada en 8.192 decisiones por método y presupuesto.
Separación: celdas de 16 con menor MSE y mayor fallo PEC en el modelo,
resueltas por encima de tolerancias numéricas (MSE 1e-12 y riesgo 1e-6).
El MSE empírico y todos los resultados por celda se incluyen en los archivos.

Costo igual por decisión: B*9 shots, es decir 6.912, 27.648 y 110.592.
Gamma^2 no se cobra otra vez como shots. Son presupuestos del experimento
simulado, no consumos de hardware. No se evalúa el costo de aprender ruido.

3. COMPARACIÓN PRINCIPAL PREFIJADA: B={cfg['primary_budget']}
Diferencia MSE empírico PEC menos Raw: {d['mse_empirical']:.8f}.
Intervalo bootstrap exploratorio del 90%: [{ci['mse_empirical'][0]:.8f}, {ci['mse_empirical'][1]:.8f}].
Diferencia de fracaso empírico PEC menos Raw: {100*d['failure_empirical']:.2f} puntos.
Intervalo bootstrap exploratorio del 90%: [{100*ci['failure_empirical'][0]:.2f}, {100*ci['failure_empirical'][1]:.2f}] puntos.
Se remuestrean los ocho paisajes, manteniendo ambos ruidos juntos. No se
tratan las 8.192 repeticiones como paisajes independientes. No hay ajuste
de significancia confirmatoria: esta es una muestra exploratoria pequeña.

4. CONTROL DE LA APROXIMACIÓN GAUSSIANA
El riesgo discreto se calculó mediante convolución a B shots e incluye
los empates como fallos. Los momentos de PEC provienen de su ley firmada.
Error absoluto medio/máximo del riesgo gaussiano respecto del discreto:
  Raw: {gaussian['Raw']['mean_abs_error']:.6f} / {gaussian['Raw']['max_abs_error']:.6f}.
  PEC: {gaussian['Signed-PEC']['mean_abs_error']:.6f} / {gaussian['Signed-PEC']['max_abs_error']:.6f}.
Umbrales descriptivos prefijados: media <=0,02; máximo <=0,05.
Raw cumple: {gaussian['Raw']['within_prespecified_descriptive_thresholds']}.
PEC cumple: {gaussian['Signed-PEC']['within_prespecified_descriptive_thresholds']}.
Este control es una evaluación con momentos conocidos, no un selector
operativo que aprenda el riesgo de datos finitos.

5. QUÉ CAMBIA RESPECTO DEL PROXY
La varianza real es Gamma^2 E_abs[h^2]-(E_ideal[h])^2, dividida entre B;
no se impone Gamma^2 Var_ideal(h)/B. Entre celdas y presupuestos, el cociente
medio por candidato entre varianza real y la del proxy varía desde
{min(ratios):.4f} hasta {max(ratios):.4f}. Ver proxy_diagnostic.csv.
Estos son paisajes y puertas definidos para este nuevo control. Sus cifras
no sustituyen ni corrigen directamente los ocho POM del manuscrito v40.

6. VERIFICACIÓN Y ALCANCE
Controles PASS: ruido cero, identidad del promedio firmado, momentos de
orden cuatro, ties estrictos, convolución frente a binomial/enumeración,
integración gaussiana, reproducibilidad de todos los conteos por semilla,
49.152 decisiones recalculadas y costos. La convolución se contrastó con
el doble de longitud FFT en el primer paisaje, todos sus ruidos/presupuestos.
El MSE y el fallo empíricos se contrastaron con sus incertidumbres de
muestreo, sin retocar semillas ni excluir celdas después de observarlos.

No se demuestra una ventaja universal de PEC ni un resultado de hardware.
El canal conocido, las correcciones ideales, la independencia de registros
y el pequeño conjunto de circuitos delimitan lo que se ha comprobado.
El manuscrito v40, el paquete sellado v4 y los pilotos anteriores permanecen
intactos. No se publicó ni se incorporó nada automáticamente al paper.

7. ARCHIVOS Y REPRODUCCIÓN
protocol.json/PROTOCOLO.txt: protocolo previo. freeze.json: fuentes y hashes.
laws/: distribuciones completas. records/: conteos, sumas y decisiones.
cell_results.csv: resultados por celda. results.json: agregados e intervalos.
proxy_diagnostic.csv: comparación secundaria con el proxy anterior.
comparacion_pec.png/.svg: figura independiente del manuscrito.
verification_unit.json/verification_post.json: controles y discrepancias.
Los módulos auditados usados están incluidos sin cambios en vendor/daqem.

En el proyecto: python -B verify.py post comprueba también los archivos
externos protegidos. En otra ubicación, python -B verify.py post --archive-only
reproduce conteos y decisiones del archivo sin requerir la ruta del paper
original y sin reescribir el informe de verificación. Las versiones están
en requirements.txt. Para volver a simular las leyes desde cero se requiere
una carpeta de ejecución nueva; los scripts rechazan sobrescribir evidencia.
'''
    (P/'INFORME.txt').write_text(report,encoding='utf-8')
    study.write(P/'completion.json',dict(timestamp_utc=study.now(),status='COMPLETE',
        primary_signature=status,integrity='PASS',manuscript_modified=False,auto_incorporation=False))
    files=sorted(f for f in P.rglob('*') if f.is_file() and f.name!='manifest_sha256.json')
    study.write(P/'manifest_sha256.json',{str(f.relative_to(P)).replace('\\','/'):study.sha(f) for f in files})
    archive=P.parent/'pec_decisiones_v2.zip'
    if archive.exists():raise RuntimeError('Archive already exists')
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
        for f in sorted(P.rglob('*')):
            if f.is_file():z.write(f,Path(P.name)/f.relative_to(P))
    with zipfile.ZipFile(archive) as z:assert z.testzip() is None
    print(json.dumps(dict(report=str(P/'INFORME.txt'),figure=str(P/'comparacion_pec.png'),
                         archive=str(archive),sha256=study.sha(archive)),indent=2))


if __name__=='__main__':main()
