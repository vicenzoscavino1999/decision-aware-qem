"""Independent arithmetic, distribution and replay checks for the PEC study."""
import sys
sys.dont_write_bytecode=True
import argparse
from itertools import product
import numpy as np
from scipy.stats import binom
from scipy.special import ndtr
import model
import study


def unit():
    checks={}
    probabilities=np.array([.32,.41,.28]);B=21
    pmf=np.array([[1-p,p] for p in probabilities])
    exact=np.array([binom.pmf(np.arange(B+1),B,p) for p in probabilities])
    less=np.c_[np.zeros(3),np.cumsum(exact,axis=1)[:,:-1]]
    risk=1-np.sum(exact[0]*less[1]*less[2])
    value,diag=model.discrete_failure(pmf,B,0)
    assert abs(value-risk)<1e-12
    checks['fft_vs_analytic_binomial_risk_abs_error']=abs(value-risk)
    rng=np.random.default_rng(2026102340)
    p=rng.dirichlet(np.ones(4),size=3);B=5
    dist=[]
    for row in p:
        law=np.array([1.])
        for _ in range(B):law=np.convolve(law,row)
        dist.append(law)
    strict=sum(dist[0][i]*dist[1][j]*dist[2][k] for i,j,k in product(range(16),repeat=3) if i>j and i>k)
    value,_=model.discrete_failure(p,B,0)
    assert abs(value-(1-strict))<1e-12
    checks['fft_strict_ties_vs_exhaustive_sum_abs_error']=abs(value-(1-strict))
    assert np.array_equal(model.strict_winners_max(np.array([[2,2,0],[0,2,1],[4,1,1]])),[-1,1,0])
    gr,_=model.gaussian_failure(np.zeros(3),np.ones(3),0)
    assert abs(gr-2/3)<1e-10
    gr,_=model.gaussian_failure(np.array([0.,1.]),np.array([1.,2.]),0)
    assert abs(gr-ndtr(-1/np.sqrt(3)))<1e-10
    checks['shared_reference_gaussian_analytic_controls']=True
    # Exact fourth-moment formula checked against a binomial sample mean law.
    p=.23;B=17;truth=np.array([.4])
    mean,mom=model.centered_moments(np.array([[1-p,p]]),np.array([0.,1.]))
    mse,se=model.mse_expectation_and_sampling_se(mean,mom,truth,B,1)
    error=np.arange(B+1)/B-truth[0];mass=binom.pmf(np.arange(B+1),B,p)
    expected=float(mass@(error**2));variance=float(mass@(error**4)-expected**2)
    assert abs(mse-expected)<1e-12 and abs(se**2-variance)<1e-12
    checks['mse_fourth_moment_sampling_variance_exact_check']=True
    graph=study.nx.cycle_graph(4);angles=np.array([[.63,.29],[.43,.37]])
    law=model.primitive_laws(graph,angles,1,0.,0.)
    assert np.max(np.abs(law['joint_cut'][:,1]))<1e-12
    assert np.max(np.abs(law['joint_cut'][:,0]-law['raw_cut']))<1e-12
    checks['zero_noise_signed_pec_reduces_to_raw']=True
    law=model.primitive_laws(graph,angles,1,.01,.03)
    m=graph.number_of_edges();k=np.arange(m+1);gamma=float(law['gamma']);joint=law['joint_cut']
    values=(-m/2+gamma*np.stack([m/2-k,-(m/2-k)])).ravel()
    means,mom=model.centered_moments(joint.reshape(2,-1),values)
    ideal=law['ideal_cut']@(-k)
    assert np.max(np.abs(means-ideal))<1e-12
    q=joint[:,0]+joint[:,1,::-1]
    transformed=-m/2+gamma*(m/2-k)
    tm,tv=model.centered_moments(q,transformed)
    assert np.max(np.abs(tm-means))<1e-12 and np.max(np.abs(tv-mom))<1e-10
    checks['folded_integer_statistic_preserves_signed_law_moments']=True
    return checks


def post(check_external=True):
    study.check_freeze(protected=check_external);cfg=study.config();P=study.P
    import csv
    rows=list(csv.DictReader((P/'cell_results.csv').open(encoding='utf-8')))
    receipt=study.read(P/'sampling_receipt.json');law_receipt=study.read(P/'laws_receipt.json')
    max_mean_error=0.;mse_z=[];risk_z=[];count=0;double_errors=[];max_cov_error=[]
    assert len(rows)==cfg['landscapes']*len(cfg['noise'])*len(cfg['budgets_per_candidate'])*2
    for name,h in law_receipt['sha256'].items():
        assert study.sha(P/'laws'/name)==h
        with np.load(P/'laws'/name) as z:
            law={k:z[k] for k in z.files}
        raw=law['raw_cut'];joint=law['joint_cut'];ideal=law['ideal_cut'];gamma=float(law['gamma'])
        n,m1=raw.shape;m=m1-1;k=np.arange(m1)
        truth=ideal@(-k);star=int(np.argmin(truth));cell=name[:-4];key,noise=cell.split('_',1)
        assert abs(joint.sum(axis=(1,2)).min()-1)<1e-12 and joint.min()>=0
        assert np.max(np.abs(joint[:,1].sum(-1)-(1-1/gamma)/2))<1e-12
        values=(-m/2+gamma*np.stack([m/2-k,-(m/2-k)])).ravel()
        mean,mom=model.centered_moments(joint.reshape(n,-1),values)
        max_mean_error=max(max_mean_error,float(np.max(np.abs(mean-truth))))
        # Different expression for second moment: abs-law centered observable.
        abs_cut=joint.sum(1)
        v=gamma**2*(abs_cut@((m/2-k)**2))-(truth+m/2)**2
        assert np.max(np.abs(v-mom[:,0]))<1e-10
        for B in cfg['budgets_per_candidate']:
            name=f'{cell}_B{B}.npz';assert study.sha(P/'records'/name)==receipt['files_sha256'][name]
            with np.load(P/'records'/name) as z:
                r={k:z[k] for k in z.files}
            rc=r['raw_counts'];pc=r['pec_joint_counts']
            assert np.all(rc.sum(-1)==B) and np.all(pc.sum(axis=(-1,-2))==B)
            raw_rng=study.rng_for(cfg['seed'],cell,B,'Raw');pec_rng=study.rng_for(cfg['seed'],cell,B,'Signed-PEC')
            for j in range(n):
                assert np.array_equal(rc[:,j],raw_rng.multinomial(B,raw[j],size=cfg['repetitions']))
                expected=pec_rng.multinomial(B,joint[j].ravel(),size=cfg['repetitions']).reshape(cfg['repetitions'],2,m1)
                assert np.array_equal(pc[:,j],expected)
            raw_sums=rc@k;pec_sums=pc[:,:,0]@k+pc[:,:,1]@(m-k)
            # Independent expression retaining sign explicitly, including the known constant.
            signed_integer=(pc[:,:,0]@(m-2*k))-(pc[:,:,1]@(m-2*k))
            exact_pec=-m/2+gamma*signed_integer/(2*B)
            assert np.max(np.abs(exact_pec-r['pec_estimates']))<1e-12
            assert np.array_equal(pec_sums,r['pec_integer_statistic']) and np.array_equal(raw_sums,r['raw_integer_statistic'])
            assert np.array_equal(r['winners'][:,0],model.strict_winners_max(raw_sums))
            assert np.array_equal(r['winners'][:,1],model.strict_winners_max(-signed_integer))
            for method,mi,values in [('Raw',0,-raw_sums/B),('Signed-PEC',1,exact_pec)]:
                row=next(x for x in rows if x['landscape']==key and x['noise']==noise and int(x['budget'])==B and x['method']==method)
                empirical_mse=float(np.mean((values-truth)**2));failure=float(np.mean(r['winners'][:,mi]!=star))
                assert abs(empirical_mse-float(row['mse_empirical']))<1e-12
                assert failure==float(row['failure_empirical'])
                assert int(row['total_shots_per_decision'])==B*n
                mse_z.append(abs(empirical_mse-float(row['mse_expected']))/max(float(row['mse_empirical_se']),1e-14))
                risk_z.append(abs(failure-float(row['failure_discrete']))/max(float(row['failure_empirical_se']),1/cfg['repetitions']))
                count+=len(values)
            # Prespecified first landscape, every noise and budget, both methods.
            if key=='PS001':
                for method,p in [('Raw',raw),('Signed-PEC',joint[:,0]+joint[:,1,::-1])]:
                    actual,_=model.discrete_failure(p,B,star,padding_multiplier=2)
                    row=next(x for x in rows if x['landscape']==key and x['noise']==noise and int(x['budget'])==B and x['method']==method)
                    double_errors.append(abs(actual-float(row['failure_discrete'])))
    assert max_mean_error<1e-11
    assert max(double_errors)<cfg['technical_tolerances']['fft_doubled_padding_risk']
    assert max(mse_z)<5,('MSE sampling discrepancy',max(mse_z))
    assert max(risk_z)<5,('Failure sampling discrepancy',max(risk_z))
    return dict(frozen_sources_unchanged=True,external_protected_files_checked=check_external,all_distributions_and_count_hashes_match=True,
        random_records_reproduced_from_seeds=True,decisions_replayed=count,all_shot_costs_balance=True,
        signed_mean_unbiased_max_error=max_mean_error,fft_doubled_padding_max_risk_difference=max(double_errors),
        empirical_mse_max_standardized_discrepancy=max(mse_z),empirical_failure_max_standardized_discrepancy=max(risk_z))


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('stage',choices=['unit','post']);parser.add_argument('--archive-only',action='store_true')
    args=parser.parse_args();stage=args.stage
    checks=unit() if stage=='unit' else post(check_external=not args.archive_only)
    result=dict(status='PASS',timestamp_utc=study.now(),checks=checks)
    if not args.archive_only: study.write(study.P/f'verification_{stage}.json',result)
    print(__import__('json').dumps(result,indent=2))
